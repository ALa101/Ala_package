def swap_tow_value(n1, n2):
    n2, n1 = n1, n2
    return n1, n2
def add_number(n1, n2, n3=0, n4=0):
    return n1 + n2 + n3 + n4 + n4


def sub_number(n1, n2):
    return n1 - n2
